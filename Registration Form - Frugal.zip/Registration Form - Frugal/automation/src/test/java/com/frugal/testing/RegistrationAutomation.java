package com.frugal.testing;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.time.Duration;

public class RegistrationAutomation {

    private static WebDriver driver;
    // Update this to your local path if not running from the project root
    // We assume the html is in the parent directory of this automation folder
    // Adjust logic dynamically:
    private static final String HTML_FILE_PATH = Paths.get(System.getProperty("user.dir")).getParent().resolve("index.html").toUri().toString();

    public static void main(String[] args) {
        setup();
        
        try {
            System.out.println("--- STARTING AUTOMATION ---");
            System.out.println("Target: " + HTML_FILE_PATH);

            // Flow C: Logic Validation (Do this first to test interactive elements)
            executeFlowC();
            
            // Refresh to start clean for Sequence A -> B
            driver.navigate().refresh();
            
            // Flow A: Negative Scenario
            executeFlowA();
            
            // Flow B: Positive Scenario (Continues from A's state but fixes data)
            executeFlowB();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            tearDown();
        }
    }

    private static void setup() {
        System.out.println("Setting up WebDriver...");
        // Setup ChromeDriver automatically
        WebDriverManager.chromedriver().setup();
        
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");
        options.addArguments("--remote-allow-origins=*");
        
        driver = new ChromeDriver(options);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5)); // Indirect wait for elements
        
        // 1. Launch page
        driver.get(HTML_FILE_PATH);
        
        // 2. Print Details
        System.out.println("Page Title: " + driver.getTitle());
        System.out.println("Page URL: " + driver.getCurrentUrl());
    }

    private static void executeFlowA() throws InterruptedException, IOException {
        System.out.println("\n--- Excuting Flow A: Negative Scenario ---");
        
        // 3. Fill Form (Skip Last Name)
        getElement("firstName").sendKeys("Alice");
        // Skipped lastName
        getElement("email").sendKeys("alice@example.com");
        
        // Country first to enable phone
        new Select(getElement("country")).selectByVisibleText("India");
        
        getElement("phone").sendKeys("9876543210");
        getElement("age").sendKeys("28");
        
        // Gender (Radio)
        WebElement genderFemale = driver.findElement(By.cssSelector("input[value='Female']"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", genderFemale); // Click safely

        getElement("password").sendKeys("Strong@Pass1");
        getElement("confirmPassword").sendKeys("Strong@Pass1");
        
        // Terms
        WebElement terms = getElement("terms");
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", terms);

        // 4. Click Submit
        WebElement submitBtn = getElement("submitBtn");
        // Note: Our JS disables the button if validation fails. 
        // Flow A expectation says "Click Submit". 
        // If our JS code disables the button, we can't click it normally.
        // However, standard negative tests often check if button IS disabled or if clicking produces errors.
        // The prompt says "Required fields must show inline error messages if empty".
        // And "Submit button must remain disabled until ALL required validations pass".
        // So actually, we CANNOT click submit if validation works correctly.
        // We should verify the button is DISABLED and the inline error is shown.
        // BUT, the prompt Flow A says: "4. Click the Submit button." and "5. Validate ... Error message is displayed".
        // This implies the previous "Client Side Validation" might allow clicking OR the prompt implies checking the validation *attempt*.
        // Since my implementation DISABLES the button, I will check if it is disabled, 
        // OR I will try to click and catch the state.
        // For the sake of the script matching the prompt, I will attempt click, but if disabled, I will print that validation is working.
        
        if(submitBtn.isEnabled()) {
            submitBtn.click();
        } else {
            System.out.println("Button is disabled as expected due to missing fields.");
        }
        
        // 5. Validate Error Message for missing Last Name
        // Since I made the field required, the error span #lastNameError should be visible or the input have .invalid class
        // Trigger blur to show error if not already shown (JS shows on input/blur)
        getElement("lastName").click(); 
        getElement("firstName").click(); // Blur away
        
        WebElement lastNameError = getElement("lastNameError");
        WebElement lastNameInput = getElement("lastName");
        
        boolean isErrorDisplayed = lastNameError.isDisplayed() || lastNameInput.getAttribute("class").contains("invalid");
        
        if (isErrorDisplayed) {
            System.out.println("PASS: Error state detected for missing Last Name.");
        } else {
            System.out.println("FAIL: No error state for missing Last Name.");
        }

        // 6. Capture Screenshot
        captureScreenshot("error-state.png");
    }

    private static void executeFlowB() throws InterruptedException, IOException {
        System.out.println("\n--- Excuting Flow B: Positive Scenario ---");

        // 1. Refill with valid data
        getElement("lastName").sendKeys("Smith"); // Fix the missing field
        
        // Ensure others are still there and valid.
        
        // 2. Ensure Password Match
        // (Already filled in Flow A, but let's re-verify)
        
        // 3. Ensure Terms Selected
        // (Selected in Flow A)
        
        // 4. Click Submit
        // Now button should be enabled
        WebElement submitBtn = getElement("submitBtn");
        Thread.sleep(500); // Wait for JS to update button state
        
        if(submitBtn.isEnabled()) {
            submitBtn.click();
            System.out.println("Clicked Submit.");
        } else {
            System.out.println("FAIL: Submit button is still disabled!");
            return;
        }
        
        // 5. Validate Success
        WebElement successMsg = getElement("feedbackMessage");
        Thread.sleep(500); // Wait for transition
        
        if (successMsg.isDisplayed() && successMsg.getText().contains("Registration Successful")) {
            System.out.println("PASS: Success message displayed.");
        } else {
            System.out.println("FAIL: Success message not found.");
        }
        
        // Validate Reset (Check if First Name is empty)
        if (getElement("firstName").getAttribute("value").isEmpty()) {
            System.out.println("PASS: Form fields reset.");
        } else {
            System.out.println("FAIL: Form fields not reset.");
        }

        // 6. Capture Screenshot
        captureScreenshot("success-state.png");
    }

    private static void executeFlowC() throws InterruptedException {
        System.out.println("\n--- Excuting Flow C: Logic Validation ---");

        // 1. Country -> State Logic
        Select countrySelect = new Select(getElement("country"));
        countrySelect.selectByVisibleText("USA");
        System.out.println("Selected Country: USA");
        
        Select stateSelect = new Select(getElement("state"));
        // Verify states contain a USA state like "California"
        boolean hasCalifornia = stateSelect.getOptions().stream().anyMatch(o -> o.getText().equals("California"));
        System.out.println("State Dropdown updated: " + hasCalifornia);

        if (!hasCalifornia) System.out.println("FAIL: State not updated for USA");

        // 2. State -> City Logic
        stateSelect.selectByVisibleText("California");
        System.out.println("Selected State: California");
        
        Select citySelect = new Select(getElement("city"));
        // Verify cities contain "San Francisco"
        boolean hasSF = citySelect.getOptions().stream().anyMatch(o -> o.getText().equals("San Francisco"));
        System.out.println("City Dropdown updated: " + hasSF);
        
        if (!hasSF) System.out.println("FAIL: City not updated for California");

        // 3. Password Strength
        WebElement pwd = getElement("password");
        pwd.sendKeys("weak"); 
        // Check strength text (assuming id="strengthText")
        WebElement strengthText = getElement("strengthText");
        System.out.println("Password Strength for 'weak': " + strengthText.getText());
        
        pwd.clear();
        pwd.sendKeys("StrongP@ss1");
        System.out.println("Password Strength for 'StrongP@ss1': " + strengthText.getText());

        // 4. Mismatch Confirm Password
        getElement("confirmPassword").sendKeys("Mismatch123");
        pwd.click(); // Blur to trigger check
        
        WebElement confirmError = getElement("confirmPasswordError");
        if (confirmError.isDisplayed()) {
            System.out.println("PASS: Mismatch error displayed.");
        } else {
            System.out.println("FAIL: Mismatch error NOT displayed.");
        }

        // 5. Verify Submit Button Disabled
        WebElement submitBtn = getElement("submitBtn");
        if (!submitBtn.isEnabled()) {
            System.out.println("PASS: Submit button is disabled (Form incomplete).");
        } else {
            System.out.println("FAIL: Submit button is enabled prematurely.");
        }
        
        // Clear for next flow
        pwd.clear();
        getElement("confirmPassword").clear();
    }

    // Helper to get element by ID
    private static WebElement getElement(String id) {
        return driver.findElement(By.id(id));
    }

    private static void captureScreenshot(String fileName) throws IOException {
        TakesScreenshot screenshot = (TakesScreenshot) driver;
        File srcFile = screenshot.getScreenshotAs(OutputType.FILE);
        File destFile = new File(fileName);
        FileUtils.copyFile(srcFile, destFile);
        System.out.println("Screenshot saved: " + destFile.getAbsolutePath());
    }

    private static void tearDown() {
        if (driver != null) {
            System.out.println("Closing browser...");
            driver.quit();
        }
    }
}
