// Data for Independent Dropdowns
const locationData = {
    "India": {
        code: "+91",
        states: {
            "Telangana": ["Hyderabad", "Warangal", "Nizamabad"],
            "Karnataka": ["Bengaluru", "Mysuru", "Hubballi"],
            "Maharashtra": ["Mumbai", "Pune", "Nagpur"]
        }
    },
    "USA": {
        code: "+1",
        states: {
            "California": ["San Francisco", "Los Angeles", "San Diego"],
            "Texas": ["Dallas", "Houston", "Austin"],
            "New York": ["New York City", "Buffalo", "Albany"]
        }
    },
    "UK": {
        code: "+44",
        states: {
            "England": ["London", "Manchester", "Liverpool"],
            "Scotland": ["Edinburgh", "Glasgow", "Aberdeen"]
        }
    }
};

const disposableDomains = [
    "tempmail.com", "mailinator.com", "10minutemail.com", "guerrillamail.com", "yopmail.com"
];

document.addEventListener('DOMContentLoaded', () => {
    // Elements
    const form = document.getElementById('registrationForm');
    const submitBtn = document.getElementById('submitBtn');
    const countrySelect = document.getElementById('country');
    const stateSelect = document.getElementById('state');
    const citySelect = document.getElementById('city');
    const countryCodeInput = document.getElementById('countryCode');
    
    // Inputs to validate
    const inputs = {
        firstName: document.getElementById('firstName'),
        lastName: document.getElementById('lastName'),
        email: document.getElementById('email'),
        phone: document.getElementById('phone'),
        age: document.getElementById('age'),
        country: countrySelect,
        password: document.getElementById('password'),
        confirmPassword: document.getElementById('confirmPassword'),
        terms: document.getElementById('terms'),
        gender: document.getElementsByName('gender') 
    };

    // --- Dropdown Logic ---
    function populateCountries() {
        for (let country in locationData) {
            let option = document.createElement('option');
            option.value = country;
            option.textContent = country;
            countrySelect.appendChild(option);
        }
    }

    countrySelect.addEventListener('change', function() {
        const country = this.value;
        stateSelect.innerHTML = '<option value="">Select State</option>';
        citySelect.innerHTML = '<option value="">Select City</option>';
        citySelect.disabled = true;

        if (country) {
            stateSelect.disabled = false;
            countryCodeInput.value = locationData[country].code;
            
            const states = locationData[country].states;
            for (let state in states) {
                let option = document.createElement('option');
                option.value = state;
                option.textContent = state;
                stateSelect.appendChild(option);
            }
        } else {
            stateSelect.disabled = true;
            countryCodeInput.value = "+";
        }
        validateField(this);
        checkFormValidity();
    });

    stateSelect.addEventListener('change', function() {
        const country = countrySelect.value;
        const state = this.value;
        citySelect.innerHTML = '<option value="">Select City</option>';

        if (state && country) {
            citySelect.disabled = false;
            const cities = locationData[country].states[state];
            cities.forEach(city => {
                let option = document.createElement('option');
                option.value = city;
                option.textContent = city;
                citySelect.appendChild(option);
            });
        } else {
            citySelect.disabled = true;
        }
        checkFormValidity(); // State is not explicitly required by prompt, but usually is. 
                             // Prompt said "Country -> State -> City must be dynamically linked."
                             // Prompt said fields 1-4, 6, 8, 11-13 are required. 
                             // However, implicit logic usually demands state if country has states.
                             // I will treat State/City as optional based on prompt requirement list (items 9,10 are NOT marked Required in list, only 1,2,3,4,6,8,11,12,13).
                             // Wait, logic says "Country (Dropdown)" and "State (Dropdown - dependent)".
                             // Requirement 8 says "Country (Dropdown)", Requirement 9 says "State...".
                             // Only items marked (Required) are 1,2,3,4,6,8(implied generic req?), 13.
                             // Actually, let's look at strict functional requirements.
                             // 1. FN(Req), 2. LN(Req), 3. Email(Req), 4. Phone(Req), 6. Gender(Req), 13. Terms(Req).
                             // 8. Country is not explicitly marked "(Required)" in text, but usually is.
                             // 11. Password not marked "(Required)" but has rules, so implied.
                             // I will make Country Required (it drives phone code) and Password Required. 
                             // I will leave State/City as optional to strictly follow "Required" tags, 
                             // BUT checking valid inputs usually implies selecting them if available. 
                             // Let's stick to the list: 1, 2, 3, 4, 6, 13 are explicitly marked.
                             // Actually, looking at the prompt:
                             // "1. First Name (Required)" ... "8. Country (Dropdown)"
                             // Validation Rules say "Required fields must show inline error messages".
                             // So strict list: 1, 2, 3, 4, 6, 13.
                             // However, without Country selected, we can't do Phone validation (Country code).
                             // So Country MUST be required for Phone validation to work. I will make Country required.
    });

    // --- Validation Logic ---

    function showError(input, id) {
        if (!id && input.type === 'radio') {
            id = 'genderError';
        } else if (!id) {
            id = input.id + 'Error';
        }
        
        const errorMsg = document.getElementById(id);
        if (errorMsg) {
            input.classList.add('invalid');
            if (input.type === 'radio') {
                document.querySelector('.checkbox-group').classList.add('invalid');
            } else if(input.type === 'checkbox') {
                 document.querySelector('.term-group').classList.add('invalid');
            }
             else {
                input.parentElement.classList.add('invalid'); // for phone group
            }
        }
    }

    function clearError(input, id) {
        if (!id && input.type === 'radio') {
            id = 'genderError';
        } else if (!id) {
            id = input.id + 'Error';
        }

        const errorMsg = document.getElementById(id);
        if (errorMsg) {
            input.classList.remove('invalid');
            if (input.type === 'radio') {
                document.querySelector('.checkbox-group').classList.remove('invalid');
            } else if(input.type === 'checkbox') {
                 document.querySelector('.term-group').classList.remove('invalid');
            } else {
                input.parentElement.classList.remove('invalid');
            }
        }
    }

    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!re.test(email)) return "Invalid email format";
        
        const domain = email.split('@')[1];
        if (disposableDomains.includes(domain)) {
            return "Disposable email addresses are not allowed";
        }
        return null;
    }

    function validatePhone(phone) {
        if (!/^\d+$/.test(phone)) return "Phone must be numeric";
        // Simple length check, can be improved based on country
        if (phone.length < 10) return "Phone number too short";
        return null; 
    }

    function getPasswordStrength(password) {
        let text = "";
        let color = "";
        let width = "0%";
        let score = 0;

        if (password.length > 0) {
            if (password.length >= 8) score++;
            if (/[A-Z]/.test(password)) score++;
            if (/[a-z]/.test(password)) score++;
            if (/[0-9]/.test(password)) score++;
            if (/[^A-Za-z0-9]/.test(password)) score++;
        }

        if (score < 3) {
            text = "Weak";
            color = "#ef4444"; // red
            width = "30%";
        } else if (score < 5) {
            text = "Medium";
            color = "#f59e0b"; // yellow
            width = "60%";
        } else {
            text = "Strong";
            color = "#10b981"; // green
            width = "100%";
        }
        
        return { text, color, width, score };
    }

    function validateField(input) {
        let isValid = true;
        
        // 1. Required Check
        if (input.hasAttribute('required')) {
            if (input.type === 'checkbox') {
                 if(!input.checked) isValid = false;
            } else if (input.type === 'radio') {
                // Radio check handled separately usually, but here checking name group
                const radios = document.getElementsByName(input.name);
                let checked = false;
                for(let r of radios) if(r.checked) checked = true;
                if(!checked) isValid = false;
            } else {
                if(!input.value.trim()) isValid = false;
            }
        }

        if (!isValid) {
            showError(input);
            return false;
        }

        // 2. Specific Validations
        if (input.id === 'email') {
            const error = validateEmail(input.value);
            if (error) {
                document.getElementById('emailError').textContent = error;
                showError(input);
                return false;
            } else {
                 document.getElementById('emailError').textContent = "Enter a valid email address"; // reset default
            }
        }

        if (input.id === 'phone') {
            const error = validatePhone(input.value);
            if (error) {
                document.getElementById('phoneError').textContent = error;
                showError(input);
                return false;
            }
        }
        
        if (input.id === 'password') {
             const strength = getPasswordStrength(input.value);
             const bar = document.getElementById('strengthBar');
             const text = document.getElementById('strengthText');
             
             bar.style.width = strength.width;
             bar.style.backgroundColor = strength.color;
             text.textContent = strength.text;
             text.style.color = strength.color;

             // Rule: Min 8 chars, 1 Uppercase, 1 Lowercase, 1 Number, 1 Special
             const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
             // Relaxing regex slightly to allow any special char:
             const strongRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,}$/;
             
             if (!strongRegex.test(input.value)) {
                 showError(input);
                 return false;
             }
        }
        
        if (input.id === 'confirmPassword') {
            if (input.value !== inputs.password.value) {
                showError(input);
                return false;
            }
        }

        clearError(input);
        return true;
    }

    function checkFormValidity() {
        // Run specific validations on all required fields
        const reqInputs = form.querySelectorAll('[required]');
        let allValid = true;

        reqInputs.forEach(input => {
            // Re-use logic, but don't show error if empty during typing unless touched? 
            // Requirement: "Submit button must remain disabled until ALL required validations pass"
            
            // Basic required check
            if (input.type === 'radio') {
                 const radios = document.getElementsByName(input.name);
                 let checked = false;
                 for(let r of radios) if(r.checked) checked = true;
                 if(!checked) allValid = false;
            } else if (input.type === 'checkbox') {
                 if(!input.checked) allValid = false;
            } else {
                 if(!input.value.trim()) allValid = false;
            }

            // Specific checks
            if (input.id === 'email' && validateEmail(input.value)) allValid = false;
            if (input.id === 'phone' && validatePhone(input.value)) allValid = false;
            
            // Password Check
            if (input.id === 'password') {
                 const strongRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,}$/;
                 if (!strongRegex.test(input.value)) allValid = false;
            }
            if (input.id === 'confirmPassword') {
                if (input.value !== document.getElementById('password').value) allValid = false;
            }
        });

        submitBtn.disabled = !allValid;
    }

    // --- Events ---
    
    // Attach input listeners
    const allInputs = form.querySelectorAll('input, select');
    allInputs.forEach(input => {
        input.addEventListener('input', () => {
            validateField(input);
            checkFormValidity();
        });
        input.addEventListener('blur', () => {
             validateField(input);
             checkFormValidity();
        });
        
        // Special case for Confirm password to re-validate when Password changes
        if(input.id === 'password') {
             input.addEventListener('input', () => {
                 if(inputs.confirmPassword.value) validateField(inputs.confirmPassword);
             });
        }
    });

    // Initialize
    populateCountries();


    // --- Submission ---
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        
        // One final check (though button should be disabled)
        checkFormValidity();
        if (submitBtn.disabled) return;

        // Simulate API call / Success
        const feedback = document.getElementById('feedbackMessage');
        feedback.textContent = "Registration Successful! Your profile has been submitted successfully.";
        feedback.className = "feedback-message success";
        
        // Reset form
        form.reset();
        submitBtn.disabled = true;
        
        // Reset dynamic fields and visuals
        document.getElementById('strengthBar').style.width = '0%';
        document.getElementById('strengthText').textContent = '';
        stateSelect.innerHTML = '<option value="">Select State</option>';
        stateSelect.disabled = true;
        citySelect.innerHTML = '<option value="">Select City</option>';
        citySelect.disabled = true;
        countryCodeInput.value = "+";
        
        // Scroll to top
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
});
